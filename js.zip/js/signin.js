
var button=document.getElementById("login");
button.onclick=function (){
    window.location.href="login.htm"
}